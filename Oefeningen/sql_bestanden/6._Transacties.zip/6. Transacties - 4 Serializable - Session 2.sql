-- Session 2

BEGIN TRANSACTION
INSERT INTO dbo.TestIsolationLevels VALUES (3428, 'Phantom Employee 2', 30000)
COMMIT